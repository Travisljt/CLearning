
#pragma once
#include "../dict.h"
#define KHASHES 11

struct dict{
    int size;
    long long int * a;
};

