#include "common.h"

void strrevletters(const char* s1, char* s2)
{
}
