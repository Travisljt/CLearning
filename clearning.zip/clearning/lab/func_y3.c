#include "common.h"

bool adj(const bool a[15][15], int n)
{
}
