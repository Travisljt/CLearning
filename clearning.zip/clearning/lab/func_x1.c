#include "common.h"

bool strsimilar(const char* s1, const char* s2)
{
}
