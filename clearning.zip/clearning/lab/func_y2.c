#include "common.h"

int uniquenums(const int a[5][5])
{
}
