#include "common.h"

int arrrun(const int a[5][5])
{
}
