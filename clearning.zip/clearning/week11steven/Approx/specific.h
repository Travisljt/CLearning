#include "../dict.h"

struct dict {
    int size;
    long long int *arr;
};

