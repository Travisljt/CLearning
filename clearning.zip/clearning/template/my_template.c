#include<stdio.h>
#include<assert.h>
#include<stdbool.h>
#include<stdlib.h>

#define X 10

typedef enum Color{red, blue, yello} Color;

struct suit
{
    Color st;
    int change;
};


void fuction1(int a, int b);
void fuction2(int t, int s);

int main(void)
{
  return 0;
}

void fuction1(int a, int b)
{

}

void fuction2(int t, int s)
{
    
}